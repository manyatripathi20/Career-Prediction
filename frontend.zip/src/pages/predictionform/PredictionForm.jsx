import { useState } from "react";
import "./PredictionForm.css";
import Loading from "../../components/loading/Loading";
import { useDispatch } from "react-redux";
import { addPredictionsDB } from "../../features/userSlice";

const PredictionForm = ({ user }) => {
  const dispatch = useDispatch();

  const [formActive, setformActive] = useState(true);
  const [result, setresult] = useState("");
  const [loading, setloading] = useState(false);
  const [formData, setFormData] = useState({
    Name: "",
    Age: "",
    Sex: "",
    "10th Percentage": "",
    "12th Percentage": "",
    Hobbies: "",
    Skills: "",
    IQ: "",
    Test: "",
    Personality: "",
  });

  const getDateTime = () => {
    let currentdate = new Date();
    let date = currentdate.toDateString();
    let time = currentdate.toLocaleTimeString();
    return [date, time];
  };

  const handleChange = (event) => {
    setFormData({ ...formData, [event.target.name]: event.target.value });
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setloading(true);
    try {
      let res = await fetch(import.meta.env.VITE_FLASK_BACKEND, {
        // mode: 'no-cors',
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          Accept: "application/json",
        },
        body: JSON.stringify(formData),
      });
      // Handle the response (success or error)
      await res.json().then((data) => {
        let predictionsMedia = {
          ...data,
          ...formData,
          timestamp: getDateTime(),
        };
        setresult(data);
        dispatch(
          addPredictionsDB({ media: predictionsMedia, email: user.email })
        );
        setformActive(false);
      });
    } catch (error) {
      console.error("Error submitting form data:", error);
    } finally {
      setloading(false);
    }
  };

  return loading ? (
    <Loading />
  ) : formActive ? (
    <form className="pred-form" onSubmit={handleSubmit}>
      <h2>Student Information Form</h2>
      <div className="form-container">
        <div className="input-div">
          <label htmlFor="Name">Name:</label>
          <input
            type="text"
            id="Name"
            name="Name"
            value={formData.Name}
            onChange={handleChange}
            required
          />
        </div>
        <div className="input-div">
          <label htmlFor="Age">Age:</label>
          <input
            type="number"
            id="Age"
            name="Age"
            value={formData.Age}
            onChange={handleChange}
            required
          />
        </div>
        <div className="input-div">
          <label htmlFor="Sex">Sex:</label>
          <select
            id="Sex"
            name="Sex"
            value={formData.Sex}
            onChange={handleChange}
            required
          >
            <option value="">Select</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
            <option value="Other">Other</option>
          </select>
        </div>
        <div className="input-div">
          <label htmlFor="10th Percentage">10th Percentage:</label>
          <input
            type="number"
            id="10th Percentage"
            name="10th Percentage"
            value={formData["10th Percentage"]}
            onChange={handleChange}
            required
          />
        </div>
        <div className="input-div">
          <label htmlFor="12th Percentage">12th Percentage:</label>
          <input
            type="number"
            id="12th Percentage"
            name="12th Percentage"
            value={formData["12th Percentage"]}
            onChange={handleChange}
            required
          />
        </div>
        <div className="input-div">
          <label htmlFor="Hobbies">Hobbies:</label>
          <input
            type="text"
            id="Hobbies"
            name="Hobbies"
            value={formData.Hobbies}
            onChange={handleChange}
            required
          />
        </div>
        <div className="input-div">
          <label htmlFor="Skills">Skills:</label>
          <input
            type="text"
            id="Skills"
            name="Skills"
            value={formData.Skills}
            onChange={handleChange}
            required
          />
        </div>
        <div className="input-div">
          <label htmlFor="IQ">IQ:</label>
          <input
            type="number"
            id="IQ"
            name="IQ"
            value={formData.IQ}
            onChange={handleChange}
            required
          />
        </div>
        <div className="input-div">
          <label htmlFor="Test">General Test Score ( 0-100 ):</label>
          <input
            type="number"
            id="Test"
            name="Test"
            value={formData.Test}
            onChange={handleChange}
            required
          />
        </div>
        <div className="input-div">
          <label htmlFor="Personality">Personality:</label>
          <select
            id="Personality"
            name="Personality"
            value={formData.Personality}
            onChange={handleChange}
            required
          >
            <option value="">Select</option>
            <option value="Extroverted">Extroverted</option>
            <option value="Introverted">Introverted</option>
            <option value="Ambiverted">Ambiverted</option>
          </select>
        </div>
      </div>
      <button type="submit">Submit</button>
    </form>
  ) : (
    <div className="pred-result">
      <h1>Prediction Result</h1>
      <p>
        Hi, <span>{result.username}</span>, the best suited career option for you is {" "}
        <span>{result.career}</span> 
        </p>
      <button
        onClick={() => {
          setformActive((prev) => !prev);
          setFormData({
            Name: "",
            Age: "",
            Sex: "",
            "10th Percentage": "",
            "12th Percentage": "",
            Hobbies: "",
            Skills: "",
            IQ: "",
            Test:"",
            Personality: "",
          });
        }}
      >
        Predict Again
      </button>
    </div>
    
  );
};

export default PredictionForm;
